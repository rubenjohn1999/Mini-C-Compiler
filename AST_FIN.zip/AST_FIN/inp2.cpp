int main()
{
	int a=2;
	float b;
	if(a==3)
	{
		int z=5;
	}
}
