int main()
{
	int a = 6;
	float b;
	if(x==2)
	{
		int y=5;
		cout << "hello";
	}
	float end;
}
