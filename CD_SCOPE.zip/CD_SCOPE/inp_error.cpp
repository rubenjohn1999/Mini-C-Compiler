int main()
{
	int a
	int d=10;
	int b
	int y;
	if a==2
	{
		int x=b;
	}
}
