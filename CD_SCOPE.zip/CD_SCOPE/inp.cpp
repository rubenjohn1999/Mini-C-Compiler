int def=0;
int main() 
{
	int i3, n, arr[3];
	{
		int a=3, scope1;
		i3=10*5;
		int n;
	}
	{
		a=5;
		int b;
	}
	for (int i = 0; i<13; i++) {
		float k = 55.123;
		if (i==2) {
			short efj = 123;
			cout >> "hello";
			cout << "error!";
		}
		int j = i;
		long count1 = 35;
		while (j<5) 
		{
			int n=22;
			float temp_var1=2, temp_var2;
			n = i;
			j+=1; //across scope
		}
	}
	return 0;
}

