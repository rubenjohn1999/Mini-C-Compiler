int main()
{

	int i;
	int a=1;
	int b;
	for(i=0;i<10;i++)	
	{
		if(i==5)
		{
			int res = a+b;
		}
		int c = a + b;
	}
	a += 1;	
	b -= 1;
	b = b + 2;
}
