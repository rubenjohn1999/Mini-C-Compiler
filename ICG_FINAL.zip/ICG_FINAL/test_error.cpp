int main()
{
	int a;
	int b = 'd';
	if(a>7)
	{
		cout << a;
		cout >> a;
	}
	int e
	int f = 5
	int g;
}
